package sprintmodulo5.controlador;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet("/EditarClienteServlet")
public class EditarClienteServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    
}